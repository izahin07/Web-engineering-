var count = 0;

//variables
var quiz = [];
quiz[0] = new Question(
  "What does Au stand for in the periodic table?",
  "Copper",
  "Sodium",
  "Gold"
);
quiz[1] = new Question(
  "What unit is used to measure horses?",
  "Hand",
  "Scale",
  "Tape"
);
quiz[2] = new Question(
  "What is the highest number used in a Sudoku puzzle?",
  "Nine",
  "Seven",
  "Twelve"
);
quiz[3] = new Question(
  "Which swimming stroke is named after an insect?",
  "Butterfly",
  "Bee",
  "Bittle"
);
quiz[4] = new Question(
  "What is the term for a positive electrode?",
  "Kathode",
  "Anode",
  "Electron"
);
quiz[5] = new Question(
  "What is a female deer called?",
  "Doe",
  "Mamba",
  "Deer"
);

quiz[6] = new Question(
  "Which country does opera singer Pavarotti come from?",
  "Italy",
  "England",
  "London"
);
quiz[7] = new Question(
  "How is 77 represented in Roman numerals?",
  "LXXVII",
  "XXVVIV",
  "XXXVVI"
);
quiz[8] = new Question(
  "Who earned the nickname “Slowhand”?",
  "Daniels",
  "Milton",
  "Eric Clapton"
);
quiz[9] = new Question(
  "Betz cells are found in which part of the body?",
  "Brain",
  "Kidney",
  "Heart"
);

var randomQuestion;
var answers = [];
var currentScore = 0;

document.addEventListener("DOMContentLoaded", function (event) {
  btnProvideQuestion();
});

function Question(question, rightAnswer, wrongAnswer1, wrongAnswer2) {
  this.question = question;
  this.rightAnswer = rightAnswer;
  this.wrongAnswer1 = wrongAnswer1;
  this.wrongAnswer2 = wrongAnswer2;
}

function shuffle(o) {
  for (
    var j, x, i = o.length;
    i;
    j = parseInt(Math.random() * i), x = o[--i], o[i] = o[j], o[j] = x
  );
  return o;
}

function btnProvideQuestion() {
  if (count != 5) {
    var randomNumber = Math.floor(Math.random() * quiz.length);
    randomQuestion = quiz[randomNumber]; //getQuestion
    answers = [
      randomQuestion.rightAnswer,
      randomQuestion.wrongAnswer1,
      randomQuestion.wrongAnswer2,
    ];
    shuffle(answers);

    document.getElementById("question").innerHTML = randomQuestion.question;
    document.getElementById("answerA").value = answers[0];
    document.getElementById("answerA").innerHTML = answers[0];
    document.getElementById("answerB").value = answers[1];
    document.getElementById("answerB").innerHTML = answers[1];
    document.getElementById("answerC").value = answers[2];
    document.getElementById("answerC").innerHTML = answers[2];
  } else {
    alert("Quiz Finish");
    document.getElementById("question").innerHTML = "";
    document.getElementById("answerA").innerHTML = "";
    document.getElementById("answerB").innerHTML = "";
    document.getElementById("answerC").innerHTML = "";
  }
  count++;
}

function answerA_clicked() {
  var answerA = document.getElementById("answerA").value;
  checkAnswer(answerA);
}

function answerB_clicked() {
  var answerB = document.getElementById("answerB").value;
  checkAnswer(answerB);
}
function answerC_clicked() {
  var answerC = document.getElementById("answerC").value;

  checkAnswer(answerC);
}

function adjustScore(isCorrect) {
  debugger;
  if (isCorrect) {
    currentScore++;
  }

  document.getElementById("score").innerHTML = currentScore;
}

function checkAnswer(answer) {
  if (answer == randomQuestion.rightAnswer) {
    btnProvideQuestion();
    adjustScore(true);
  } else {
    alert(
      `You Enter a Wrong Answer!! Correct Answer is:  ${randomQuestion.rightAnswer}`
    );

    btnProvideQuestion();
  }
}
